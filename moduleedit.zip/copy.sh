#! /bin/bash
cp Highlight.css ./node_modules/react-pdf-highlighter/build/style/

cp Highlight.js ./node_modules/react-pdf-highlighter/build/components/

echo "FILES COPIED"
